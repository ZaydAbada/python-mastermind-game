#Create function that returns a code of 4 colours from a list of 6 colours. The options should be: Red, Green, Blue, Yellow, White, Orange. 

import random

def Generate_code() -> list:
    colours = ['Red', 'Green', 'Blue', 'Yellow', 'White', 'Orange']
    code = random.sample(colours, 4)
    return code 