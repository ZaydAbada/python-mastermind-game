def PlayAgain()-> bool:
    while True:
        play_again = input("Do you want to play again? (Y/N): ").strip().lower()
        if play_again in ['y', 'yes']:
            return True
        elif play_again in ['n', 'no']:
            print("Thanks for playing! Goodbye!")
            return False
        else:
            print("Invalid input. Please enter 'Y' or 'N'.")