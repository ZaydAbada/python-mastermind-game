from itertools import product

COLOURS = ["Red", "Green", "Blue", "Yellow", "White", "Orange"]

def generate_all_candidates():
    return [list(c) for c in product(COLOURS, repeat=4)]

def score(secret, guess):
    black = sum(1 for s, g in zip(secret, guess) if s == g)
    secret_rem = [s for s, g in zip(secret, guess) if s != g]
    guess_rem  = [g for s, g in zip(secret, guess) if s != g]
    white = sum(min(secret_rem.count(c), guess_rem.count(c)) for c in set(guess_rem))
    return black, white

def filter_candidates(candidates, guess, black, white):
    return [c for c in candidates if score(c, guess) == (black, white)]

def get_next_guess(candidates):
    return candidates[0]  # simplest: pick first remaining candidate