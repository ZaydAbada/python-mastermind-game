def ValidateGuess(guess: list) -> bool:
   
    valid_colours = {"Red", "Green", "Blue", "Yellow", "White", "Orange"}  
    if not isinstance(guess, list):  
        return False
    if len(guess) != 4:  
        return False
    if not all(colour in valid_colours for colour in guess): 
        return False
    return True