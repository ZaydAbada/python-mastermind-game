from typing import Dict, Any
from src.logic import PlayAgain
from src.logic.CodeGenerator import Generate_code
from src.logic.GetUserGuess import GetUserInput
from src.logic.ValidateGuess import ValidateGuess
from src.ui.UserFeedback import Display_feedback
from src.ui.displaygameover import DisplayGameOverScreen
from src.ui.DisplayError import DisplayError
from src.ui.DisplayMode1GameRules import DisplayMode1GameRules

def run_game(max_attempts: int = 10) -> Dict[str, Any]:
	"""Run the core game loop (single function, not a class).

	Uses `generate_code`, `getUserInput`, `ValidateGuess`, `display_feedback`,
	and `DisplayGameOverScreen` from the provided modules.

	Returns a dict with the outcome: `{'won': bool, 'attempts': int, 'code': list}`.
	"""

	secret_code = Generate_code()
	attempts = 0
	code_length = len(secret_code)

	
	DisplayMode1GameRules(max_attempts, code_length)

	while attempts < max_attempts:
		guess = GetUserInput()

		if not isinstance(guess, list):
			DisplayError("Invalid input format. Please enter your colours as a comma-separated list.")
			continue

		if not ValidateGuess(guess):
			DisplayError("Invalid guess. Enter 4 colours from: Red, Green, Blue, Yellow, White, Orange.")
			# Do not count invalid guesses against attempts
			continue

		attempts += 1

		# Calculate exact (black) matches
		black = sum(1 for s, g in zip(secret_code, guess) if s == g)

		# Calculate partial (white) matches: correct colour, wrong position
		# Exclude exact matches first
		secret_remaining = []
		guess_remaining = []
		for s, g in zip(secret_code, guess):
			if s != g:
				secret_remaining.append(s)
				guess_remaining.append(g)

		white = 0
		for colour in set(guess_remaining):
			white += min(secret_remaining.count(colour), guess_remaining.count(colour))

		# Display feedback using provided UI function
		Display_feedback(black, white)

		if black == code_length:
			DisplayGameOverScreen(True, secret_code, attempts, max_attempts)
			return {"won": True, "attempts": attempts, "code": secret_code}

		print(f"Attempts remaining: {max_attempts - attempts}\n")

	# Ran out of attempts
	DisplayGameOverScreen(False, secret_code, attempts, max_attempts)
	PlayAgain()	
	return {"won": False, "attempts": attempts, "code": secret_code}


