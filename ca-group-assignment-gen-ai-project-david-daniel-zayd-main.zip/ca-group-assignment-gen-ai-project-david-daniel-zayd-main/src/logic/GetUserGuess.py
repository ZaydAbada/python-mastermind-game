
def GetUserInput():
	"""Prompt the user to enter 4 colours and return them as a list.

	The function only collects input; it does not validate the colours or count.
	The prompt asks for comma-separated values.
	"""
	raw = input("Enter 4 colours separated by commas from: Red, Green, Blue, Yellow, White, Orange.")
	# Split on commas and strip whitespace; do not validate length or values
	colours = [part.strip() for part in raw.split(',')]
	return colours

