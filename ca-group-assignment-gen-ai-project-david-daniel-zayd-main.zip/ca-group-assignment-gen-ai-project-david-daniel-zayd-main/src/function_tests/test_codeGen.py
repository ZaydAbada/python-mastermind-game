#Make a test for the code generator function. The test should check that the function returns a list of 4 colours from the list of 6 colours. The options should be: Red, Green, Blue, Yellow, White, Orange.


from CodeGenerator import Generate_code

def test_generate_code():
    code = Generate_code()
    assert isinstance(code, list), "Code should be a list"
    assert len(code) == 4, "Code should contain exactly 4 colours"
    valid_colours = {"Red", "Green", "Blue", "Yellow", "White", "Orange"}
    for colour in code:
        assert colour in valid_colours, f"Colour '{colour}' is not valid"