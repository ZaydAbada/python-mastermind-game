# test_ValidateGuess.py

import pytest
from ValidateGuess import ValidateGuess

def test_valid_guess():
    # Test with a valid guess
    assert ValidateGuess(["Red", "Green", "Blue", "Yellow"]) == True

def test_invalid_type():
    # Test with an invalid type (not a list)
    assert ValidateGuess("Red, Green, Blue, Yellow") == False

def test_invalid_length():
    # Test with an invalid length (not 4 elements)
    assert ValidateGuess(["Red", "Green", "Blue"]) == False
    assert ValidateGuess(["Red", "Green", "Blue", "Yellow", "White"]) == False

def test_invalid_colours():
    # Test with invalid colours
    assert ValidateGuess(["Red", "Green", "Blue", "Purple"]) == False
    assert ValidateGuess(["Black", "White", "Orange", "Yellow"]) == False

def test_empty_guess():
    # Test with an empty list
    assert ValidateGuess([]) == False

def test_case_sensitivity():
    # Test with case sensitivity
    assert ValidateGuess(["red", "green", "blue", "yellow"]) == False

def test_duplicate_colours():
    # Test with duplicate valid colours
    assert ValidateGuess(["Red", "Red", "Blue", "Yellow"]) == True