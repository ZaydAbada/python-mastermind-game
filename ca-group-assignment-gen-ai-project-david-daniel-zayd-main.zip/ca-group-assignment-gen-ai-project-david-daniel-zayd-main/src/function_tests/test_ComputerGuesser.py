# test_ComputerGuesser.py
from ComputerGuesser import generate_all_candidates, score, filter_candidates

def test_all_candidates_count():
    assert len(generate_all_candidates()) == 1296

def test_score_all_exact():
    assert score(["Red","Green","Blue","Yellow"], 
                 ["Red","Green","Blue","Yellow"]) == (4, 0)

def test_score_all_wrong():
    assert score(["Red","Red","Red","Red"], 
                 ["Blue","Blue","Blue","Blue"]) == (0, 0)

def test_score_partial():
    assert score(["Red","Green","Blue","Yellow"], 
                 ["Green","Red","Yellow","Blue"]) == (0, 4)

def test_filter_removes_inconsistent():
    candidates = generate_all_candidates()
    guess = ["Red", "Red", "Green", "Green"]
    filtered = filter_candidates(candidates, guess, 0, 0)
    # None of the remaining candidates should contain Red or Green
    for c in filtered:
        assert "Red" not in c
        assert "Green" not in c