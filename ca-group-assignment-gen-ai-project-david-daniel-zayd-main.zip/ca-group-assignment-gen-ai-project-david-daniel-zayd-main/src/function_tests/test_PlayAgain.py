# test_PlayAgain.py

import pytest
from PlayAgain import PlayAgain

def test_play_again_yes(monkeypatch):

    monkeypatch.setattr('builtins.input', lambda _: "Y")
    assert PlayAgain() == True

  
    monkeypatch.setattr('builtins.input', lambda _: "yes")
    assert PlayAgain() == True

def test_play_again_no(monkeypatch):
    
    monkeypatch.setattr('builtins.input', lambda _: "N")
    assert PlayAgain() == False

  
    monkeypatch.setattr('builtins.input', lambda _: "no")
    assert PlayAgain() == False

def test_play_again_invalid_then_yes(monkeypatch):

    inputs = iter(["invalid", "Y"])
    monkeypatch.setattr('builtins.input', lambda _: next(inputs))
    assert PlayAgain() == True

def test_play_again_invalid_then_no(monkeypatch):
   
    inputs = iter(["invalid", "N"])
    monkeypatch.setattr('builtins.input', lambda _: next(inputs))
    assert PlayAgain() == False