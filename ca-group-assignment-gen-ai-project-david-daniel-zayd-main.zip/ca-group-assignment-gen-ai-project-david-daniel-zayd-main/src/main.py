from src.logic.GameEngine import run_game
from src.ui.mode2_cli import run_mode2


def main():
	print("Welcome to Mastermind!")
	print("1. Player guesses the computer's code (Mode 1)")
	print("2. Computer guesses your code (Mode 2)")

	choice = input("Select mode (1 or 2): ").strip()

	if choice == "1":
		run_game()
	elif choice == "2":
		run_mode2()
	else:
		print("Invalid choice, starting Mode 1 by default.")
		run_game()


if __name__ == "__main__":
	main()
