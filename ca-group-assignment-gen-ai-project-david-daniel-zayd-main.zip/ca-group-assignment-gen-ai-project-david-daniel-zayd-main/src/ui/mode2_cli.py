from src.logic.ComputerGuesser import generate_all_candidates, filter_candidates, get_next_guess

def run_mode2():
    print("Think of a secret code. The computer will try to guess it.")
    print("Colours: Red, Green, Blue, Yellow, White, Orange")

    candidates = generate_all_candidates()
    guess = ["Red", "Red", "Green", "Green"]  # standard opening guess
    attempts = 0

    while attempts < 10:
        print(f"\nComputer guesses: {guess}")
        attempts += 1

        try:
            black = int(input("How many EXACT (right colour, right position)? "))
            white = int(input("How many PARTIAL (right colour, wrong position)? "))
        except ValueError:
            print("Please enter numbers.")
            continue

        if black == 4:
            print(f"Computer cracked your code in {attempts} attempts!")
            return

        candidates = filter_candidates(candidates, guess, black, white)

        if not candidates:
            print("No valid candidates remain — check your feedback was correct.")
            return

        guess = get_next_guess(candidates)

    print("Computer ran out of guesses.")