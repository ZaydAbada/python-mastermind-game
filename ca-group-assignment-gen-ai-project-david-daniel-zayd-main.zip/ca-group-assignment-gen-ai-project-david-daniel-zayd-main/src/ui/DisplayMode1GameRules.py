def DisplayMode1GameRules(numberOfGuesses: int, codeLength: int) -> None:
    print("Welcome to Mastermind!")
    print(f"The computer will generate a secret code consisting of {codeLength} colours.")
    print(f"You have {numberOfGuesses} attempts to guess the code.")
    print("After each guess, you will receive feedback:")