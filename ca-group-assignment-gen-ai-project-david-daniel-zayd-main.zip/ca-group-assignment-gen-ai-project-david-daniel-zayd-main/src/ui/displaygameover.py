# Displays the final result and reveals the secret code.

def DisplayGameOverScreen(won, secret_code, guesses_used, max_guesses):

    print("GAME OVER")

    if won:
        print("Congratulations you have guessed correctly, You win!")
    else:
        print("Hard Luck, You lose!")

    print("Secret code:", secret_code)
    print("Guesses used:", guesses_used, "/", max_guesses)