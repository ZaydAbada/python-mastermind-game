def DisplayError(message: str) -> None:
    print(f"{message}")