# Displays feedback to the player showing how many colours are correct
# in the correct position and how many are correct but in the wrong position
def Display_feedback(black: int, white: int, other:str) -> None:
    print("\nFeedback:")
    print("Correct colour and position:", black)
    print("Correct colour but wrong position:", white)
    print(other)
