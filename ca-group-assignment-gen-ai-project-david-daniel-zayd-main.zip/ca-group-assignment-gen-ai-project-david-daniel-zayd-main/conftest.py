# conftest.py - This file is used to set up the testing environment for pytest. 
# It modifies the system path to include the "src/logic" directory, allowing the test files to import modules from that directory without issues. 
# This is necessary because the test files are located in a different directory than the source code they are testing. By adding "src/logic" to the system path.
#  we ensure that the tests can access the necessary functions and classes defined in that directory.

import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "src", "logic"))